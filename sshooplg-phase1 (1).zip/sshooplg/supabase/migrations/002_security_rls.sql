-- sshooplg | Phase 1 | Row Level Security
create or replace function is_admin() returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from admins where user_id = auth.uid()) $$;

create or replace function is_manager() returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from admins where user_id = auth.uid() and role in ('owner','manager')) $$;

create or replace function is_owner() returns boolean language sql stable security definer set search_path = public as
$$ select exists (select 1 from admins where user_id = auth.uid() and role = 'owner') $$;

-- Enable RLS everywhere
do $$ declare t text; begin
  for t in select tablename from pg_tables where schemaname='public' loop
    execute format('alter table %I enable row level security', t);
  end loop;
end $$;

-- ===== Public catalog (read-only) =====
create policy pub_categories  on categories        for select using (is_active);
create policy pub_products    on products          for select using (is_active);
create policy pub_images      on product_images    for select using (exists (select 1 from products p where p.id = product_id and p.is_active));
create policy pub_variants    on product_variants  for select using (is_active and exists (select 1 from products p where p.id = product_id and p.is_active));
create policy pub_wilayas     on wilayas           for select using (true);
create policy pub_communes    on communes          for select using (true);
create policy pub_shipping    on shipping_prices   for select using (is_active);
create policy pub_banners     on banners           for select using (is_active);
create policy pub_sections    on homepage_sections for select using (is_visible);
create policy pub_pages       on pages             for select using (is_active);
create policy pub_settings    on store_settings    for select using (key not like 'private\_%');
create policy pub_reviews     on reviews           for select using (is_approved or user_id = auth.uid());

-- ===== Admin full access (staff: operations; manager+: config) =====
do $$ declare t text; begin
  foreach t in array array['categories','products','product_images','product_variants','communes','banners','homepage_sections','pages',
                           'coupons','coupon_products','customers','addresses','orders','order_items','order_status_history','reviews','notifications','users']
  loop execute format('create policy admin_all on %I for all using (is_admin()) with check (is_admin())', t); end loop;
  foreach t in array array['wilayas','shipping_prices','store_settings']
  loop execute format('create policy mgr_write on %I for all using (is_manager()) with check (is_manager())', t); end loop;
end $$;
-- shipping/settings must also be readable by admins even when inactive/private
create policy mgr_read_shipping on shipping_prices for select using (is_admin());
create policy mgr_read_settings on store_settings  for select using (is_admin());

-- admins table: only the owner manages staff; every admin can see own row
create policy admins_self  on admins for select using (user_id = auth.uid() or is_owner());
create policy admins_owner on admins for all    using (is_owner()) with check (is_owner());

-- ===== Customers' own data =====
create policy users_self_read   on users for select using (id = auth.uid());
create policy users_self_update on users for update using (id = auth.uid()) with check (id = auth.uid());

create policy cust_self    on customers for select using (user_id = auth.uid());
create policy addr_self    on addresses for all    using (exists (select 1 from customers c where c.id = customer_id and c.user_id = auth.uid()))
                                                   with check (exists (select 1 from customers c where c.id = customer_id and c.user_id = auth.uid()));
create policy orders_self  on orders      for select using (user_id = auth.uid());
create policy items_self   on order_items for select using (exists (select 1 from orders o where o.id = order_id and o.user_id = auth.uid()));
-- NOTE: no INSERT/UPDATE policy on orders for clients. Orders are created ONLY via place_order() (server, service_role).

create policy reviews_insert on reviews for insert with check (user_id = auth.uid() and is_approved = false);
create policy wishlist_self  on wishlist for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy cart_self      on cart     for all using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy cart_items_self on cart_items for all
  using (exists (select 1 from cart c where c.id = cart_id and c.user_id = auth.uid()))
  with check (exists (select 1 from cart c where c.id = cart_id and c.user_id = auth.uid()));
create policy notif_self_read   on notifications for select using (user_id = auth.uid());
create policy notif_self_update on notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());

-- Block self-escalation: a normal user can never change is_blocked
create or replace function guard_user_update() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not is_admin() and auth.uid() is not null and new.is_blocked is distinct from old.is_blocked then
    raise exception 'not allowed';
  end if;
  return new;
end $$;
create trigger trg_guard_user before update on users for each row execute function guard_user_update();

-- ===== Storage buckets =====
insert into storage.buckets (id, name, public) values
  ('product-images','product-images', true),
  ('site-assets','site-assets', true)
on conflict (id) do nothing;

create policy "public read images" on storage.objects for select using (bucket_id in ('product-images','site-assets'));
create policy "admin write images" on storage.objects for all
  using (bucket_id in ('product-images','site-assets') and is_admin())
  with check (bucket_id in ('product-images','site-assets') and is_admin());
