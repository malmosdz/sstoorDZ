-- sshooplg | Phase 1 | Server-side order engine (prices can never come from the client)

create or replace function place_order(
  p_user_id   uuid,
  p_name      text,
  p_phone     text,
  p_email     text,
  p_wilaya    smallint,
  p_commune   text,
  p_address   text,
  p_delivery  delivery_type,
  p_notes     text,
  p_items     jsonb,              -- [{product_id, variant_id?, quantity}]
  p_coupon    text default null,
  p_payment   payment_method default 'cod'
) returns table (order_id uuid, order_number text, total numeric)
language plpgsql security definer set search_path = public as $$
declare
  v_ship   shipping_prices%rowtype;
  v_cust   uuid;
  v_order  uuid := gen_random_uuid();
  v_item   jsonb;
  v_prod   products%rowtype;
  v_var    product_variants%rowtype;
  v_qty    int;
  v_unit   numeric;
  v_sub    numeric := 0;
  v_elig   numeric := 0;
  v_ship_cost numeric;
  v_disc   numeric := 0;
  v_coupon coupons%rowtype;
  v_label  text;
  v_num    text;
  v_line   numeric;
begin
  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    raise exception 'EMPTY_CART';
  end if;
  if length(trim(coalesce(p_name,''))) < 3 then raise exception 'INVALID_NAME'; end if;
  if coalesce(p_phone,'') !~ '^(0)(5|6|7)[0-9]{8}$' then raise exception 'INVALID_PHONE'; end if;
  if length(trim(coalesce(p_commune,''))) = 0 or length(trim(coalesce(p_address,''))) < 5 then raise exception 'INVALID_ADDRESS'; end if;

  select * into v_ship from shipping_prices where wilaya_code = p_wilaya and is_active;
  if not found then raise exception 'SHIPPING_UNAVAILABLE'; end if;
  v_ship_cost := case when p_delivery = 'home' then v_ship.home_price else v_ship.desk_price end;

  -- customer (registered or guest)
  if p_user_id is not null then
    insert into customers(user_id, full_name, phone, email) values (p_user_id, p_name, p_phone, p_email)
    on conflict (user_id) do update set full_name = excluded.full_name, phone = excluded.phone, email = coalesce(excluded.email, customers.email)
    returning id into v_cust;
    if exists (select 1 from users where id = p_user_id and is_blocked) then raise exception 'ACCOUNT_BLOCKED'; end if;
  else
    insert into customers(full_name, phone, email) values (p_name, p_phone, p_email) returning id into v_cust;
  end if;

  insert into orders(id, customer_id, user_id, payment_method, ship_name, ship_phone, wilaya_code, commune, address,
                     delivery_type, notes, subtotal, shipping_cost, total)
  values (v_order, v_cust, p_user_id, p_payment, p_name, p_phone, p_wilaya, trim(p_commune), trim(p_address),
          p_delivery, p_notes, 0, v_ship_cost, 0)
  returning orders.order_number into v_num;

  for v_item in select * from jsonb_array_elements(p_items) loop
    v_qty := (v_item->>'quantity')::int;
    if v_qty is null or v_qty < 1 or v_qty > 100 then raise exception 'INVALID_QUANTITY'; end if;

    select * into v_prod from products where id = (v_item->>'product_id')::uuid and is_active for update;
    if not found then raise exception 'PRODUCT_UNAVAILABLE'; end if;

    v_unit  := coalesce(v_prod.sale_price, v_prod.price);
    v_label := null;

    if (v_item->>'variant_id') is not null then
      select * into v_var from product_variants
       where id = (v_item->>'variant_id')::uuid and product_id = v_prod.id and is_active for update;
      if not found then raise exception 'VARIANT_UNAVAILABLE'; end if;
      if v_var.stock_qty < v_qty then raise exception 'OUT_OF_STOCK:%', v_prod.name; end if;
      update product_variants set stock_qty = stock_qty - v_qty where id = v_var.id;
      v_unit  := v_unit + v_var.price_delta;
      v_label := concat_ws(' / ', v_var.color, v_var.size);
    elsif v_prod.track_stock then
      if v_prod.stock_qty < v_qty then raise exception 'OUT_OF_STOCK:%', v_prod.name; end if;
    end if;

    if v_prod.track_stock then
      update products set stock_qty = greatest(stock_qty - v_qty, 0) where id = v_prod.id and (v_item->>'variant_id') is null;
    end if;

    v_line := v_unit * v_qty;
    v_sub  := v_sub + v_line;

    insert into order_items(order_id, product_id, variant_id, product_name, variant_label, unit_price, unit_cost, quantity, line_total)
    values (v_order, v_prod.id, v_var.id, v_prod.name, v_label, v_unit, v_prod.cost_price, v_qty, v_line);
    v_var := null;
  end loop;

  -- coupon
  if p_coupon is not null and length(trim(p_coupon)) > 0 then
    select * into v_coupon from coupons
     where upper(code) = upper(trim(p_coupon)) and is_active
       and (starts_at is null or starts_at <= now()) and (ends_at is null or ends_at >= now())
       and (max_uses is null or used_count < max_uses)
     for update;
    if not found then raise exception 'COUPON_INVALID'; end if;
    if v_sub < v_coupon.min_order then raise exception 'COUPON_MIN_ORDER:%', v_coupon.min_order; end if;

    if v_coupon.applies_to_all then v_elig := v_sub;
    else
      select coalesce(sum(oi.line_total),0) into v_elig from order_items oi
       where oi.order_id = v_order and oi.product_id in (select product_id from coupon_products where coupon_id = v_coupon.id);
      if v_elig = 0 then raise exception 'COUPON_NOT_APPLICABLE'; end if;
    end if;

    v_disc := case v_coupon.type when 'percent' then round(v_elig * least(v_coupon.value,100) / 100, 2)
                                 else least(v_coupon.value, v_elig) end;
    update coupons set used_count = used_count + 1 where id = v_coupon.id;
    update orders set coupon_id = v_coupon.id, coupon_code = v_coupon.code where id = v_order;
  end if;

  update orders set subtotal = v_sub, discount = v_disc, total = v_sub - v_disc + v_ship_cost where id = v_order;

  insert into order_status_history(order_id, status) values (v_order, 'pending');
  insert into notifications(user_id, title, body, link)
  values (null, 'طلب جديد ' || v_num, p_name || ' - ' || p_phone, '/admin/orders.html?id=' || v_order);

  return query select v_order, v_num, v_sub - v_disc + v_ship_cost;
end $$;

revoke all on function place_order(uuid,text,text,text,smallint,text,text,delivery_type,text,jsonb,text,payment_method) from public, anon, authenticated;
grant execute on function place_order(uuid,text,text,text,smallint,text,text,delivery_type,text,jsonb,text,payment_method) to service_role;

-- Status transitions: history, stock restore on cancel/return, sold_count on completion
create or replace function on_order_status_change() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status is distinct from old.status then
    if old.status in ('cancelled','returned') then
      raise exception 'Cannot reopen a cancelled/returned order';
    end if;
    insert into order_status_history(order_id, status, changed_by) values (new.id, new.status, auth.uid());

    if new.status in ('cancelled','returned') then
      update product_variants v set stock_qty = v.stock_qty + oi.quantity from order_items oi
        where oi.order_id = new.id and oi.variant_id = v.id;
      update products p set stock_qty = p.stock_qty + oi.quantity from order_items oi
        where oi.order_id = new.id and oi.product_id = p.id and oi.variant_id is null and p.track_stock;
      if new.coupon_id is not null then
        update coupons set used_count = greatest(used_count - 1, 0) where id = new.coupon_id;
      end if;
    elsif new.status = 'completed' then
      update products p set sold_count = p.sold_count + oi.quantity from order_items oi
        where oi.order_id = new.id and oi.product_id = p.id;
      update orders set payment_status = 'paid' where id = new.id and payment_method = 'cod';
    end if;
  end if;
  return new;
end $$;
create trigger trg_order_status after update on orders for each row execute function on_order_status_change();
