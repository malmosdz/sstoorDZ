-- sshooplg | Phase 1 | Core schema
create extension if not exists pgcrypto;
create extension if not exists pg_trgm;

-- ========== Enums ==========
create type admin_role      as enum ('owner','manager','staff');
create type order_status    as enum ('pending','confirmed','processing','shipped','completed','cancelled','returned');
create type payment_method  as enum ('cod','cib','edahabia','other');
create type payment_status  as enum ('unpaid','paid','failed','refunded');
create type delivery_type   as enum ('home','desk');
create type discount_type   as enum ('percent','fixed');
create type badge_type      as enum ('none','new','bestseller','sale');

create or replace function set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ========== Users / Admins ==========
create table users (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text,
  phone       text,
  is_blocked  boolean not null default false,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table admins (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  role        admin_role not null default 'staff',
  created_at  timestamptz not null default now()
);

create or replace function handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into users(id, full_name, phone)
  values (new.id, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'phone');
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function handle_new_user();

-- ========== Customers (guest checkout supported) ==========
create table customers (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid unique references users(id) on delete set null,
  full_name   text not null,
  phone       text not null,
  email       text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index on customers(phone);

-- ========== Geography ==========
create table wilayas (
  code     smallint primary key check (code between 1 and 58),
  name_ar  text not null,
  name_fr  text
);
create table communes (
  id          serial primary key,
  wilaya_code smallint not null references wilayas(code) on delete cascade,
  name_ar     text not null,
  name_fr     text
);
create index on communes(wilaya_code);

create table addresses (
  id           uuid primary key default gen_random_uuid(),
  customer_id  uuid not null references customers(id) on delete cascade,
  label        text,
  wilaya_code  smallint not null references wilayas(code),
  commune      text not null,
  address      text not null,
  is_default   boolean not null default false,
  created_at   timestamptz not null default now()
);

-- ========== Catalog ==========
create table categories (
  id          uuid primary key default gen_random_uuid(),
  parent_id   uuid references categories(id) on delete set null,
  name        text not null,
  slug        text not null unique,
  image_url   text,
  sort_order  int not null default 0,
  is_active   boolean not null default true,
  seo_title   text,
  seo_description text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table products (
  id             uuid primary key default gen_random_uuid(),
  category_id    uuid references categories(id) on delete set null,
  name           text not null,
  slug           text not null unique,
  description    text,
  brand          text,
  sku            text unique,
  price          numeric(12,2) not null check (price >= 0),
  sale_price     numeric(12,2) check (sale_price is null or sale_price >= 0),
  cost_price     numeric(12,2) check (cost_price is null or cost_price >= 0),
  stock_qty      int not null default 0 check (stock_qty >= 0),
  track_stock    boolean not null default true,
  badge          badge_type not null default 'none',
  is_featured    boolean not null default false,
  is_active      boolean not null default true,
  sold_count     int not null default 0,
  rating_avg     numeric(3,2) not null default 0,
  rating_count   int not null default 0,
  seo_title      text,
  seo_description text,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  constraint sale_lte_price check (sale_price is null or sale_price <= price)
);
create index on products(category_id);
create index on products(is_active, is_featured);
create index products_name_trgm on products using gin (name gin_trgm_ops);

create table product_images (
  id          uuid primary key default gen_random_uuid(),
  product_id  uuid not null references products(id) on delete cascade,
  url         text not null,
  alt         text,
  sort_order  int not null default 0
);
create index on product_images(product_id);

create table product_variants (
  id           uuid primary key default gen_random_uuid(),
  product_id   uuid not null references products(id) on delete cascade,
  color        text,
  size         text,
  sku          text unique,
  price_delta  numeric(12,2) not null default 0,
  stock_qty    int not null default 0 check (stock_qty >= 0),
  is_active    boolean not null default true
);
create index on product_variants(product_id);

-- ========== Shipping ==========
create table shipping_prices (
  wilaya_code    smallint primary key references wilayas(code),
  home_price     numeric(10,2) not null default 0 check (home_price >= 0),
  desk_price     numeric(10,2) not null default 0 check (desk_price >= 0),
  days_min       smallint not null default 2,
  days_max       smallint not null default 5,
  is_active      boolean not null default false,
  updated_at     timestamptz not null default now()
);

-- ========== Coupons ==========
create table coupons (
  id               uuid primary key default gen_random_uuid(),
  code             text not null unique,
  type             discount_type not null,
  value            numeric(12,2) not null check (value > 0),
  min_order        numeric(12,2) not null default 0,
  max_uses         int,
  used_count       int not null default 0,
  starts_at        timestamptz,
  ends_at          timestamptz,
  applies_to_all   boolean not null default true,
  is_active        boolean not null default true,
  created_at       timestamptz not null default now()
);
create table coupon_products (
  coupon_id   uuid references coupons(id) on delete cascade,
  product_id  uuid references products(id) on delete cascade,
  primary key (coupon_id, product_id)
);

-- ========== Orders ==========
create sequence order_number_seq start 1001;

create table orders (
  id              uuid primary key default gen_random_uuid(),
  order_number    text not null unique default ('SH-' || nextval('order_number_seq')),
  customer_id     uuid not null references customers(id),
  user_id         uuid references users(id) on delete set null,
  status          order_status not null default 'pending',
  payment_method  payment_method not null default 'cod',
  payment_status  payment_status not null default 'unpaid',
  ship_name       text not null,
  ship_phone      text not null,
  wilaya_code     smallint not null references wilayas(code),
  commune         text not null,
  address         text not null,
  delivery_type   delivery_type not null default 'home',
  notes           text,
  subtotal        numeric(12,2) not null,
  shipping_cost   numeric(12,2) not null,
  discount        numeric(12,2) not null default 0,
  total           numeric(12,2) not null,
  coupon_id       uuid references coupons(id) on delete set null,
  coupon_code     text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);
create index on orders(status, created_at desc);
create index on orders(customer_id);
create index on orders(user_id);

create table order_items (
  id            uuid primary key default gen_random_uuid(),
  order_id      uuid not null references orders(id) on delete cascade,
  product_id    uuid references products(id) on delete set null,
  variant_id    uuid references product_variants(id) on delete set null,
  product_name  text not null,
  variant_label text,
  unit_price    numeric(12,2) not null,
  unit_cost     numeric(12,2),
  quantity      int not null check (quantity > 0),
  line_total    numeric(12,2) not null
);
create index on order_items(order_id);

create table order_status_history (
  id          bigserial primary key,
  order_id    uuid not null references orders(id) on delete cascade,
  status      order_status not null,
  changed_by  uuid references auth.users(id),
  created_at  timestamptz not null default now()
);

-- ========== Reviews / Wishlist / Cart / Notifications ==========
create table reviews (
  id           uuid primary key default gen_random_uuid(),
  product_id   uuid not null references products(id) on delete cascade,
  user_id      uuid not null references users(id) on delete cascade,
  rating       smallint not null check (rating between 1 and 5),
  comment      text,
  is_approved  boolean not null default false,
  created_at   timestamptz not null default now(),
  unique (product_id, user_id)
);

create table wishlist (
  user_id     uuid references users(id) on delete cascade,
  product_id  uuid references products(id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (user_id, product_id)
);

create table cart (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null unique references users(id) on delete cascade,
  updated_at  timestamptz not null default now()
);
create table cart_items (
  id          uuid primary key default gen_random_uuid(),
  cart_id     uuid not null references cart(id) on delete cascade,
  product_id  uuid not null references products(id) on delete cascade,
  variant_id  uuid references product_variants(id) on delete cascade,
  quantity    int not null check (quantity > 0)
);
create unique index cart_items_unique on cart_items(cart_id, product_id, coalesce(variant_id, '00000000-0000-0000-0000-000000000000'));

create table notifications (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid references users(id) on delete cascade,  -- null = for admins
  title       text not null,
  body        text,
  link        text,
  is_read     boolean not null default false,
  created_at  timestamptz not null default now()
);

-- ========== Content / Settings ==========
create table store_settings (
  key         text primary key,
  value       jsonb not null,
  updated_at  timestamptz not null default now()
);

create table banners (
  id          uuid primary key default gen_random_uuid(),
  title       text,
  subtitle    text,
  image_url   text not null,
  link_url    text,
  button_text text,
  sort_order  int not null default 0,
  is_active   boolean not null default true
);

create table homepage_sections (
  id          uuid primary key default gen_random_uuid(),
  type        text not null check (type in ('hero','categories','bestsellers','newest','deals','recommended','reviews','custom')),
  title       text,
  config      jsonb not null default '{}',
  sort_order  int not null default 0,
  is_visible  boolean not null default true
);

create table pages (
  slug        text primary key,
  title       text not null,
  content     text not null default '',
  is_active   boolean not null default true,
  updated_at  timestamptz not null default now()
);

do $$ declare t text; begin
  foreach t in array array['users','customers','categories','products','orders','shipping_prices','store_settings','pages']
  loop execute format('create trigger trg_%I_updated before update on %I for each row execute function set_updated_at()', t, t); end loop;
end $$;

create or replace function refresh_product_rating() returns trigger language plpgsql security definer set search_path = public as $$
declare pid uuid := coalesce(new.product_id, old.product_id);
begin
  update products p set
    rating_avg   = coalesce((select round(avg(rating)::numeric,2) from reviews where product_id = pid and is_approved), 0),
    rating_count = (select count(*) from reviews where product_id = pid and is_approved)
  where p.id = pid;
  return null;
end $$;
create trigger trg_reviews_rating after insert or update or delete on reviews
  for each row execute function refresh_product_rating();
